import React, { Component } from 'react';

class Users extends Component {
    render () {
        return (
            <div>
                <h1>The Users Page</h1>
            </div>
        );
    }
}

export default Users;